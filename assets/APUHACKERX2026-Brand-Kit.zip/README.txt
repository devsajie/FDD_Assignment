APUHACKERX2026 Resource Package: APUHACKERX2026-Brand-Kit.zip
APU x LBEF STUDENT HACKATHON
BUILD. BREAK. REPEAT.
Created for CT053-3-1 Fundamentals of Web Design and Development.